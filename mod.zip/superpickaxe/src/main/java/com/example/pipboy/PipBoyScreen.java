package com.example.pipboy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

public class PipBoyScreen extends Screen {

    private static final int GREEN = 0xFF4DFF88;
    private static final int GREEN_DIM = 0xFF1F9E4A;
    private static final int SCREEN_BG = 0xFF021A0B;

    private static final String[] TABS = {"STAT", "INV", "DATA"};
    private static final int W = 340;
    private static final int H = 210;
    private static final int TAB_W = 60;
    private static final int TAB_GAP = 12;
    private static final int ROWS = 11;

    private int tab = 0;
    private int scroll = 0;
    private boolean opened = false;

    public PipBoyScreen() {
        super(Component.literal("Pip-Boy"));
    }

    @Override
    public boolean isPauseScreen() {
        return false; // die Welt laeuft weiter, die Werte aktualisieren sich live
    }

    @Override
    protected void init() {
        if (!opened) {
            opened = true;
            click();
        }
    }

    // ---------- Layout ----------

    private int px() {
        return (this.width - W) / 2;
    }

    private int py() {
        return (this.height - H) / 2;
    }

    private int tabX(int i) {
        return px() + 14 + i * (TAB_W + TAB_GAP);
    }

    private int tabY() {
        return py() + 10;
    }

    // ---------- Zeichnen ----------

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0xC0000000);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        ClientLevel level = mc.level;
        if (player == null || level == null) {
            return;
        }

        int x0 = px();
        int y0 = py();

        // Gehaeuse und Bildschirm
        g.fill(x0 - 8, y0 - 8, x0 + W + 8, y0 + H + 8, 0xFF3A3A32);
        g.fill(x0 - 4, y0 - 4, x0 + W + 4, y0 + H + 4, 0xFF111111);
        g.fill(x0, y0, x0 + W, y0 + H, SCREEN_BG);

        // Tabs
        for (int i = 0; i < TABS.length; i++) {
            int color = (i == tab) ? GREEN : GREEN_DIM;
            int tx = tabX(i) + (TAB_W - this.font.width(TABS[i])) / 2;
            text(g, TABS[i], tx, tabY(), color);
            if (i == tab) {
                g.fill(tabX(i), tabY() + 11, tabX(i) + TAB_W, tabY() + 12, GREEN);
            }
        }
        g.fill(x0 + 8, y0 + 26, x0 + W - 8, y0 + 27, GREEN_DIM);

        // Inhalt
        if (tab == 0) {
            drawStat(g, player, x0, y0);
        } else if (tab == 1) {
            drawInv(g, player, x0, y0);
        } else {
            drawData(g, player, level, x0, y0);
        }

        // Fusszeile
        g.fill(x0 + 8, y0 + H - 20, x0 + W - 8, y0 + H - 19, GREEN_DIM);
        text(g, "<- / -> oder Klick: Tab wechseln     ESC: Schließen", x0 + 14, y0 + H - 14, GREEN_DIM);

        // Scanlines fuer den Roehrenmonitor-Look
        for (int y = y0; y < y0 + H; y += 3) {
            g.fill(x0, y, x0 + W, y + 1, 0x30000000);
        }
    }

    private void drawStat(GuiGraphics g, LocalPlayer p, int x0, int y0) {
        int x = x0 + 14;
        int y = y0 + 36;

        text(g, "Name: " + p.getName().getString(), x, y, GREEN);
        y += 18;
        bar(g, "LP", x, y, p.getHealth(), p.getMaxHealth());
        y += 18;
        bar(g, "Hunger", x, y, p.getFoodData().getFoodLevel(), 20);
        y += 18;
        bar(g, "Rüstung", x, y, p.getArmorValue(), 20);
        y += 18;
        text(g, "XP-Level: " + p.experienceLevel, x, y, GREEN);
        y += 14;
        text(g, "RAD: 0 (alles sicher)", x, y, GREEN_DIM);
    }

    private void drawData(GuiGraphics g, LocalPlayer p, ClientLevel level, int x0, int y0) {
        BlockPos pos = p.blockPosition();

        long t = level.getDayTime();
        long day = t / 24000L + 1L;
        long tod = t % 24000L;
        int hour = (int) ((tod / 1000L + 6L) % 24L);
        int minute = (int) ((tod % 1000L) * 60L / 1000L);

        String biome = level.getBiome(pos).unwrapKey()
                .map(k -> Component.translatable(
                        "biome." + k.location().getNamespace() + "." + k.location().getPath()).getString())
                .orElse("?");

        String dimPath = level.dimension().location().getPath();
        String dim;
        if (dimPath.equals("overworld")) {
            dim = "Oberwelt";
        } else if (dimPath.equals("the_nether")) {
            dim = "Nether";
        } else if (dimPath.equals("the_end")) {
            dim = "Das Ende";
        } else {
            dim = dimPath;
        }

        String weather = level.isThundering() ? "Gewitter" : (level.isRaining() ? "Regen" : "Klar");

        String[] lines = {
                "Position: " + pos.getX() + " / " + pos.getY() + " / " + pos.getZ(),
                "Dimension: " + dim,
                "Biom: " + biome,
                "Tag " + day + "   Uhrzeit " + String.format("%02d:%02d", hour, minute),
                "Wetter: " + weather,
                "Lichtlevel: " + level.getMaxLocalRawBrightness(pos)
        };

        int x = x0 + 14;
        int y = y0 + 38;
        for (String line : lines) {
            text(g, line, x, y, GREEN);
            y += 16;
        }
    }

    private void drawInv(GuiGraphics g, LocalPlayer p, int x0, int y0) {
        Map<String, Integer> counts = new LinkedHashMap<>();
        int used = 0;
        for (ItemStack s : p.getInventory().items) {
            if (s.isEmpty()) {
                continue;
            }
            used++;
            counts.merge(s.getHoverName().getString(), s.getCount(), Integer::sum);
        }
        List<Map.Entry<String, Integer>> list = new ArrayList<>(counts.entrySet());

        int maxScroll = Math.max(0, list.size() - ROWS);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        text(g, "Slots belegt: " + used + " / " + p.getInventory().items.size(), x0 + 14, y0 + 34, GREEN);

        if (list.isEmpty()) {
            text(g, "Inventar leer", x0 + 14, y0 + 52, GREEN_DIM);
            return;
        }

        int y = y0 + 50;
        int end = Math.min(list.size(), scroll + ROWS);
        for (int i = scroll; i < end; i++) {
            Map.Entry<String, Integer> e = list.get(i);
            text(g, e.getKey(), x0 + 14, y, GREEN);
            String c = "x" + e.getValue();
            text(g, c, x0 + W - 16 - this.font.width(c), y, GREEN);
            y += 11;
        }

        if (list.size() > ROWS) {
            text(g, "Mausrad: scrollen (" + (scroll + 1) + "-" + end + " von " + list.size() + ")",
                    x0 + 14, y0 + H - 34, GREEN_DIM);
        }
    }

    private void bar(GuiGraphics g, String label, int x, int y, float value, float max) {
        text(g, label, x, y, GREEN);
        int bx = x + 70;
        int bw = 170;
        int bh = 8;
        float ratio = max <= 0F ? 0F : Math.max(0F, Math.min(1F, value / max));
        g.fill(bx - 1, y - 1, bx + bw + 1, y + bh + 1, GREEN_DIM);
        g.fill(bx, y, bx + bw, y + bh, SCREEN_BG);
        g.fill(bx, y, bx + (int) (bw * ratio), y + bh, GREEN);
        text(g, String.format("%.0f / %.0f", value, max), bx + bw + 8, y, GREEN);
    }

    private void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(this.font, s, x, y, color, false);
    }

    // ---------- Eingaben ----------

    private void setTab(int i) {
        tab = i;
        scroll = 0;
        click();
    }

    private void click() {
        Minecraft.getInstance().getSoundManager()
                .play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < TABS.length; i++) {
            if (mx >= tabX(i) - 4 && mx <= tabX(i) + TAB_W + 4 && my >= tabY() - 4 && my <= tabY() + 14) {
                setTab(i);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            setTab((tab + 1) % TABS.length);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            setTab((tab + TABS.length - 1) % TABS.length);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            scroll++;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            scroll--;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab == 1) {
            scroll -= (int) Math.signum(scrollY);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }
}
