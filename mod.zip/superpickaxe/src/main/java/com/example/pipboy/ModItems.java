package com.example.pipboy;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PipBoyMod.MOD_ID);

    public static final DeferredItem<PipBoyItem> PIPBOY = ITEMS.register("pipboy",
            () -> new PipBoyItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
}
