package com.example.pipboy;

import net.minecraft.client.Minecraft;

/** Reiner Client-Code. Wird nur aufgerufen, wenn level.isClientSide() gilt. */
public class PipBoyClient {

    public static void openScreen() {
        Minecraft.getInstance().setScreen(new PipBoyScreen());
    }
}
