package com.example.superpickaxe;

import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(SuperPickaxeMod.MOD_ID)
public class SuperPickaxeMod {
    public static final String MOD_ID = "superpickaxe";

    public SuperPickaxeMod(IEventBus modEventBus) {
        ModItems.ITEMS.register(modEventBus);
        modEventBus.addListener(this::addToCreativeTab);

        // Events fuer das Abbauverhalten (Spiel-Bus)
        NeoForge.EVENT_BUS.register(SuperPickaxeEvents.class);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.SUPER_PICKAXE);
        }
    }
}
