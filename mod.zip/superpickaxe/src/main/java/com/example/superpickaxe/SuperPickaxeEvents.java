package com.example.superpickaxe;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

public class SuperPickaxeEvents {

    private static boolean holdsSuperPickaxe(Player player) {
        return player.getMainHandItem().is(ModItems.SUPER_PICKAXE.get());
    }

    /** Extrem hohe Abbaugeschwindigkeit -> jeder Block geht sofort kaputt. */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        if (holdsSuperPickaxe(event.getEntity())) {
            event.setNewSpeed(1_000_000F);
        }
    }

    /** Jeder Block gilt als "richtiges Werkzeug" -> Drops gibt es immer. */
    @SubscribeEvent
    public static void onHarvestCheck(PlayerEvent.HarvestCheck event) {
        if (holdsSuperPickaxe(event.getEntity())) {
            event.setCanHarvest(true);
        }
    }

    /**
     * Unzerstoerbare Bloecke (Bedrock, Barrier, ...) haben Haerte -1 und lassen sich
     * normalerweise im Survival nie abbauen. Hier brechen wir sie per Linksklick direkt.
     */
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        Player player = event.getEntity();
        Level level = event.getLevel();

        if (level.isClientSide()) return;
        if (player.isCreative()) return;
        if (!holdsSuperPickaxe(player)) return;
        if (event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START) return;

        BlockPos pos = event.getPos();
        BlockState state = level.getBlockState(pos);

        if (state.isAir() || state.getDestroySpeed(level, pos) >= 0) return; // normaler Block

        Block.popResource(level, pos, new ItemStack(state.getBlock()));
        level.destroyBlock(pos, false, player);
        event.setCanceled(true);
    }
}
