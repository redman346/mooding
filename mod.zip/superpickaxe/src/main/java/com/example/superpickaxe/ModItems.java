package com.example.superpickaxe;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(SuperPickaxeMod.MOD_ID);

    // Kein Durability-Wert gesetzt = geht nie kaputt
    public static final DeferredItem<Item> SUPER_PICKAXE = ITEMS.registerSimpleItem(
            "super_pickaxe",
            new Item.Properties()
                    .stacksTo(1)
                    .fireResistant()
                    .rarity(Rarity.EPIC)
                    .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));
}
